/*  Accept Character from user and check whether it is digit or not  (0-9). 
Input : 7 
Output : TRUE 
Input : d 
Output : FALSE 
*/
//////////////////////////////////////////////////////////////////////////////////////

#include<stdio.h>
#include<stdbool.h>
bool CheckDigit(char ch)
{
    if((ch>='0'&& ch<='9'))
    {
        return true;
    }
    else
    {
        return false;
    }
   
}

int main()
{
    char ch='\0';
    bool bret=false;
    printf("Enetr the charachter:");
    scanf("%c",&ch);

    bret=CheckDigit(ch);

    if(bret==true)
    {
        printf("Charachter is digit.");
    }
    else
    {
        printf("Charachter is not digit.");
    }
  

    return 0;
}