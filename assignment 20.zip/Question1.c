/*  Accept Character from user and check whether it is alphabet or not  (A-Z a-z). 
Input : F 
Output : TRUE 
Input : & 
Output : FALSE 
*/
////////////////////////////////////////////////////////////////////////////////////////////////////////////


#include<stdio.h>
#include<stdbool.h>
bool CheckAlphabte(char ch)
{
    if((ch>='A'&& ch<='Z') || (ch>='a' && ch<='z'))
    {
        return true;
    }
    else
    {
        return false;
    }
   
}

int main()
{
    char ch='\0';
    bool bret=false;
    printf("Enetr the charachter:");
    scanf("%c",&ch);

    bret=CheckAlphabte(ch);

    if(bret==true)
    {
        printf("Charachter is aplphabte");
    }
    else
    {
        printf("Charachter is not alphabate.");
    }
  

    return 0;
}