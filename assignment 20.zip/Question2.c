/*  Accept Character from user and check whether it is capital or not  (A-Z). 
Input : F 
Output : TRUE 
Input : d 
Output : FALSE 
*/
////////////////////////////////////////////////////////////////////////////////////////////////////////

#include<stdio.h>
#include<stdbool.h>
bool CheckCapital(char ch)
{
    if((ch>='A'&& ch<='Z'))
    {
        return true;
    }
    else
    {
        return false;
    }
   
}

int main()
{
    char ch='\0';
    bool bret=false;
    printf("Enetr the charachter:");
    scanf("%c",&ch);

    if((ch>='A'&& ch<='Z') || (ch>='a' && ch<='z'))
    {
        bret=CheckCapital(ch);
    }
    else
    {
        printf("Special charachers or digits are not allowed.");
        return;
    }
    
    
    if(bret==true)
    {
        printf("Charachter is  capital");
    }
    else 
    {
        printf("Charachter is not capital.");
    }
  

    return 0;
}