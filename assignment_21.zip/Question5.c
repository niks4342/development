/*    Accept character from user and display its ASCII value in decimal,  octal and hexadecimal format. 
Input : A 
Output : Decimal 65 
*/


#include<stdio.h>
void Dispaly(char ch)
{
    if(ch!='\0')
    {
        printf("Decimal\tHexadecimal\tOctal\n");
        printf("%d \t   %x \t      %o \n",ch,ch,ch);
    }

}

int main()
{
    char ch='\0';
    
    printf("Enetr the charachter:\n");
    scanf("%c",&ch);

    Dispaly(ch);
    

    return 0;
}