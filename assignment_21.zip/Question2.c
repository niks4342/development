/*  Accept character from user. If character is small display its  corresponding capital character, and if it small then display its  corresponding capital.
     In other cases display as it is.*/


#include<stdio.h>
char Dispaly(char ch)
{
    if(ch>='A'&& ch<='Z')
    {
        return ch+32;
    }
    else if (ch>='a' && ch<='z')
    {
        return ch-32;
    }
    
}

int main()
{
    char ch='\0';
    char cret='\0';
    printf("Enetr the charachter:");
    scanf("%c",&ch);

    cret=Dispaly(ch);
    printf("orresponding charachter is: %c",cret);

    return 0;
}