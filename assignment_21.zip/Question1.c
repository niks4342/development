/*  Write a program which displays ASCII table. Table contains symbol,  Decimal, Hexadecimal and Octal 
    representation of every member from  0 to 255. */


#include<stdio.h>
void Display()
{
    int icnt=0;
    printf("ASCII table is:");
    printf("***********************************************************************************\n");
    printf("Symbols\t Decimal\t Hexadecimal\t Octal\n");
    printf("*********************************************************************************\n");
    
    for(icnt=0;icnt<=225;icnt++)
    {
        printf("%c \t %d \t %x \t %o\n ",icnt,icnt,icnt,icnt);
    }
}

int main()
{
    Display();
    return 0;
}