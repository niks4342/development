/*  Accept Character from user and check whether it is special symbol  or not (!, @, #, $, %, ^, &, *). 
Input : % 
Output : TRUE 
Input : d 
Output : FALSE 
*/
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include<stdio.h>
#include<stdbool.h>
bool SpecialSymbol(char ch)
{
    if((ch>='!'&& ch<='/') || (ch>=':'&& ch<='@'))
    {
        return true ;
    }
    else
    {
        return false;
    }
    
}

int main()
{
    char ch='\0';
    bool bret=false;
    printf("Enetr the charachter:");
    scanf("%c",&ch);

    bret=SpecialSymbol(ch);
   
   if(bret==true)
   {
       printf("TRUE");
   }
   else 
   {
      printf("FALSE");
   }
   

    return 0;
}