/* Write a java program which accept string from user and display  it in reverse order. */



import java.util.Scanner;

class Question5
{
    public static void main(String arg[]) 
    {
        Scanner sobj=new Scanner(System.in);
        String str1=null;
        
        
        System.out.println("Enter the string:");
        str1=sobj.nextLine();

        char brr[]=str1.toCharArray();

        Display obj=new Display();
        obj.strrevX(brr);

   
    }
}

class Display
{
    public void strrevX(char brr[])
    {
       
        for(int i=brr.length;i>0;i--)
        {
            try
            {
            System.out.println(brr[i]);
            }
            catch(Exception obj)
            {

            }
        }
    }
}