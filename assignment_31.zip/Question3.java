/* Write a java program which accept string from user and return  difference between frequency of small characters 
and frequency  of capital characters.  */


import java.util.Scanner;

class Question3
{
    public static void main(String arg[]) 
    {
        Scanner sobj=new Scanner(System.in);
        String str1=null;
        int iret=0;
        
        System.out.println("Enter the string:");
        str1=sobj.nextLine();

        char brr[]=str1.toCharArray();

        count obj=new count();
        iret=obj.Difference(brr);

        System.out.println("difference between frequency of small and  capital characters is:"+iret);
    }
}

class count
{
    public int Difference(char brr[])
    {
        int ccnt=0,scnt=0,i=0;
        
        for(i=0;i<brr.length;i++)
      {
          if(brr[i]>='A' && brr[i]<='Z')
          {
            ccnt++;
          }
          else if(brr[i]>='a' && brr[i]<='z')
          {
            scnt++;
          }
      }
      return scnt-ccnt;
    }
}
