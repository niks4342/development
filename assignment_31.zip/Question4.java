/*Write a java program which accept string from user and check  whether it contains vowels in it or not*/

 
import java.util.Scanner;

class Question4
{
    public static void main(String arg[]) 
    {
        Scanner sobj=new Scanner(System.in);
        String str1=null;
        boolean bret=false;
        
        System.out.println("Enter the string:");
        str1=sobj.nextLine();

        char brr[]=str1.toCharArray();

        check obj=new check();
        bret=obj.CheckVowel(brr);

       if(bret==true)
       {
           System.out.println("String contain vowel");
       }
       else
       {
           System.out.println("string does not contain vowel");
       }
    }
}

class check
{
    public boolean CheckVowel(char brr[])
    {
        int icnt=0,i=0;
        boolean flag=false;
        
        for(i=0;i<brr.length;i++)
      {
          if(brr[i]=='a' || brr[i]=='e'|| brr[i]=='i'|| brr[i]=='o'|| brr[i]=='u'|| brr[i]=='A'|| brr[i]=='E'|| brr[i]=='I'|| brr[i]=='O'|| brr[i]=='U')
          {
            flag=true;
            return flag;
          }

      }
    return flag;
    }
}