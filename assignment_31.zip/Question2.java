/*  Write a java program which accept string from user and count  number of small characters. */ 


import java.util.Scanner;

class Question2
{
    public static void main(String arg[]) 
    {
        Scanner sobj=new Scanner(System.in);
        String str1=null;
        int iret=0;
        
        System.out.println("Enter the string:");
        str1=sobj.nextLine();

        char brr[]=str1.toCharArray();

        count obj=new count();
        iret=obj.smallCount(brr);

        System.out.println("count of small charachter is:"+iret);
    }
}

class count
{
    public int smallCount(char brr[])
    {
        int icnt=0,i=0;
        
        for(i=0;i<brr.length;i++)
      {
          if(brr[i]>='a' && brr[i]<='z')
          {
              icnt++;
          }
      }
      return icnt;
    }
}
