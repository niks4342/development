/* Q.5    Write a program which checks whether first and last bit is On or  OFF. 
First bit means bit number 1 and last bit means bit number 32. */


#include<stdio.h>
#include<stdbool.h>

typedef unsigned int UINT;

bool CheckBit(UINT ino)
{
    UINT iret=0;
    UINT imask=0x80000001;

    iret=ino & imask;

    if(iret==imask)
    {
        return true;
    }
    else
    {
        return false;
    }
}

int main()
{
    UINT ivalue=0;
    bool bret=false;

    printf("Enter number:\n");
    scanf("%d",&ivalue);

    bret=CheckBit(ivalue);

    if(bret==true)
    {
        printf("First and last bits are ON\n");
    }
    else
    {
        printf("Bits are OFF\n");
    }

    return 0;
}