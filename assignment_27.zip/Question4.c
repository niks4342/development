/* Q.4    Write a program which checks whether 7th & 8th & 9th bit is On or  OFF.  */

#include<stdio.h>
#include<stdbool.h>

typedef unsigned int UINT;

bool CheckBit(UINT ino)
{
    UINT iret=0;
    UINT imask=0x000001C0;

    iret=ino & imask;

    if(iret==imask)
    {
        return true;
    }
    else
    {
        return false;
    }
}

int main()
{
    UINT ivalue=0;
    bool bret=false;

    printf("Enter number:\n");
    scanf("%d",&ivalue);

    bret=CheckBit(ivalue);

    if(bret==true)
    {
        printf("7th, 8th and 9th bits are ON\n");
    }
    else
    {
        printf("Bits are OFF\n");
    }

    return 0;
}