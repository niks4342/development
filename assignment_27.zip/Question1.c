/* Q.1   Write a program which checks whether 15th bit is On or OFF.  */


#include<stdio.h>
#include<stdbool.h>

typedef unsigned int UINT;

bool CheckBit(UINT ino)
{
    UINT iret=0;
    UINT imask=0x00004000;

    iret=ino & imask;

    if(iret==imask)
    {
        return true;
    }
    else
    {
        return false;
    }
}

int main()
{
    UINT ivalue=0;
    bool bret=false;

    printf("Enter the number:\n");
    scanf("%d",&ivalue);

    bret=CheckBit(ivalue);

    if(bret==true)
    {
        printf("15th bit is ON\n");
    }
    else
    {
        printf("15th bit is OFF");
    }

    return 0;
}