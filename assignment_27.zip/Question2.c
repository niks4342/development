/* Q.2    Write a program which checks whether 5th & 18th bit is On or OFF.  */

#include<stdio.h>
#include<stdbool.h>

typedef unsigned int UINT;

bool CheckBit(UINT ino)
{
    UINT iret=0;
    UINT imask=0x00020010;

    iret=ino & imask;

    if(iret==imask)
    {
        return true;
    }
    else
    {
        return false;
    }
}

int main()
{
    UINT ivalue=0;
    bool bret=false;

    printf("Enter number:\n");
    scanf("%d",&ivalue);

    bret=CheckBit(ivalue);

    if(bret==true)
    {
        printf("5th and 18th bits are ON\n");
    }
    else
    {
        printf("Bits are OFF\n");
    }

    return 0;
}