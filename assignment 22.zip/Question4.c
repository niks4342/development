/*  Write a program which accept string from user and check whether  it contains vowels in it or not. 
Input : “marvellous” 
Output : TRUE 
Input : “Demo” 
Output : TRUE 
Input : “xyz” 
Output : FALSE 
*/
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include<stdio.h>
#include<stdbool.h>

bool vowels(char *str)
{
    bool flag=false;
    while(*str!='\0')
    {
        if(*str=='a'|| *str=='e'|| *str=='i'|| *str=='o'|| *str=='u'||*str=='A'|| *str=='E'|| *str=='I'|| *str=='O'|| *str=='U')
        {
            return true;
        }
        
        str++;
    }
    return flag;
}

int main()
{
    char arr[20];
    bool bret=false;

    printf("Enter the string:\n");
    scanf("%[^'\n']s",arr);

    bret=vowels(arr);
    
    if(bret==true)
    {
        printf("TRUE(string contains the vowel) ");
    }
    else
    {
        printf("FALSE(string not contain vowel)");
    }


    return 0;
}