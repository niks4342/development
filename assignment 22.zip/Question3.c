/*  Write a program which accept string from user and return  difference between frequency of small characters 
and frequency of  capital characters. 
Input : “MarvellouS” 
Output : 6 (8-2) 
*/
///////////////////////////////////////////////////////////////////////////////////////////////////////////////


#include<stdio.h>
int count(char *str)
{
    int ccount=0,scount=0,diff=0;

    while(*str!='\0')
    {
        
       if((*str>='A') && (*str<='Z'))
        {
           ccount++;   
        }
          
       else if((*str>='a') && (*str<='z'))
        {
           scount++; 
        }
            str++;
    }
    
    diff=scount-ccount;
   return diff;

    
}

int main()
{
    char arr[20];
    int iret=0;

    printf("Enter the string:\n");
    scanf("%[^'\n']s",arr);

    iret=count(arr);
    printf("Difference between frequency of small characters and frequency of  capital characters is: %d",iret);


    return 0;
}