/*  Write a program which accept string from user and count number of  capital characters. 
Input : “Marvellous Multi OS” 
Output : 4 
*/
////////////////////////////////////////////////////////////////////////////////////////////////

#include<stdio.h>
int CountCaplital(char *str)
{
    int count=0;
    while(*str!='\0')
    {
        if((*str>='A') && (*str<='Z'))
        {
            count++;
        }       
        str++;
    }    
    return count;
}

int main()
{
    char arr[30];
    int iret=0;

    printf("Enter the string:\n");
    scanf("%[^'\n']s",arr);

    iret=CountCaplital(arr);
    printf("Count of capital charachetrs in the given string is: %d",iret);

    return 0;
}