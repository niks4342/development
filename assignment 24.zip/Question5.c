/*   Write a program which accept string from user reverse that string  in place. 
Input : “abcd” 
Output : “dcba” 
*/


#include<stdio.h>
void Display(char *str)
{
    char *start=str;
    char*end=start;

    char temp;

    while(*end!=0)
    {
        end++;
    }
    end--;

    while(start<end)
    {
        temp=*start;
        *start=*end;
        *end=temp;

        start++;
        end--;
    }

}

int main()
{
    char arr[50];
    char iret;

    printf("Enter the string:\n");
    scanf("%[^'\n']s",arr);

    Display(arr);
    printf("Reverce string is:%s\n",arr);

    return 0;
}