/*  Write a program which accept string from user and accept one  character. Return frequency of that character. 
Input : “Marvellous Multi OS” 
        M 
Output : 2 
Input : “Marvellous Multi OS” 
        W 
Output : 0 
*/
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include<stdio.h>

int Check(char *str,char cvalue)
{
    int icnt=0;
    if(str==NULL)
    {
        return -1;
    }

    while (*str!='\0')
    {
        if(*str==cvalue)
        {
           icnt++;
        }
        
        str++;
    }
    return icnt;
}

int main()
{
    char arr[30];
    int iret=0;
    char ch='\0';

    printf("Enter the string:\n");
    scanf("%[^'\n']s",arr);

    printf("Enter the charachter:\n");
    scanf(" %c",&ch);

    iret=Check(arr,ch);
    printf("frequency of given charachetr is:%d\n",iret);

    return 0;
}