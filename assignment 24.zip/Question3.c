/*  Write a program which accept string from user and accept one  character. Return index of first occurrence of that character. 
Input : “Marvellous Multi OS” 
M 
Output : 0 
*/

#include<stdio.h>

int Check(char *str,char cvalue)
{
    int i=0;
    
    
    while(str[i]!='\0')
    {
        if(*str==cvalue)
        {
            break;
        }
        else 
        {
            i++;
        }
        
        str++;
    } 
    if(str[i]!='\0')
    {
      return i;
    }
    
}

int main()
{
    char arr[30];
    int iret=0;
    char ch='\0';

    printf("Enter the string:\n");
    scanf("%[^'\n']s",arr);

    printf("Enter the charachter:\n");
    scanf(" %c",&ch);

    iret=Check(arr,ch);
   
    printf("index of given charachetr is:%d\n",iret);

    return 0;
}