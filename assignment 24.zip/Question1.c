/*  Write a program which accept string from user and accept one  character. Check whether that character is present in string or not. 
Input : “Marvellous Multi OS” 
        e 
Output : TRUE 
Input : “Marvellous Multi OS” 
        W 
Output : FALSE 
*/
////////////////////////////////////////////////////////////////////////////////////////////////////

#include<stdio.h>
#include<stdbool.h>

bool Check(char *str,char cvalue)
{
    if(str==NULL)
    {
        return -1;
    }

    while (*str!='\0')
    {
        if(*str==cvalue)
        {
            break;
        }
        
        str++;
    }
    if(*str!='\0')
    {
        return true;
    }
    else 
    {
        return false;
    }
    
    
}

int main()
{
    char arr[30];
    bool bret=false;
    char ch='\0';

    printf("Enter the string:\n");
    scanf("%[^'\n']s",arr);

    printf("Enter the charachter:\n");
    scanf(" %c",&ch);

    bret=Check(arr,ch);

    if(bret==true)
    {
        printf("TRUE\n");
    }
    else 
    {
        printf("FALSE\n");
    }
    
    return 0;
}