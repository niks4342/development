/* Write a program which accept one number and position from user and off  that bit. Return modified number. 
Input : 10 2 
Output : 8 
*/
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
#include<stdio.h>
typedef unsigned int UINT;

UINT OffBit(UINT ino,UINT ipos)
{
    UINT iret=0;
    UINT imask=0x00000001;

    imask=imask<<(ipos-1);

   iret=ino ^ imask;
  
   if(iret==imask)
   {
      return iret;
   }
   
}

int main()
{
    UINT ivalue=0,ibit=0,iret=0;

    printf("Enter number:\n");
    scanf("%d",&ivalue);

    printf("Enter posotion of bit:\n");
    scanf("%d",&ibit);

    iret=OffBit(ivalue,ibit);
    printf("modified number is:%d\n",iret);


    return 0;
}