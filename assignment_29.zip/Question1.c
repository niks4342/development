/*  Write a program which accept one number and position from user and check whether bit at that position is on or off. 
    If bit is one return TURE  otherwise return FALSE. 
Input : 10 2 
Output : TRUE 
*/

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include<stdio.h>
#include<stdbool.h>

typedef unsigned int UINT;

bool CheckBit(UINT ino,UINT ipos)
{
   UINT iret=0;
   UINT  imask=0x00000001;

   if(ipos<1 || ipos>32)
   {
       return false;
   }

    imask=imask<<(ipos-1);

   iret=ino & imask;
    
   if(iret==imask)
   {
       return true;
   }
   else
   {
       return false;
   }
}

int main()
{
    UINT ivalue=0,ibit=0;
    bool bret=false;

    printf("Enter number:\n");
    scanf("%d",&ivalue);

    printf("Enter position:\n");
    scanf("%d",&ibit);

    bret=CheckBit(ivalue,ibit);

    if(bret==true)
    {
        printf(" bit is ON\n");
    }
    else
    {
        printf(" bit is OFF\n");
    }

    return 0;
}