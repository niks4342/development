/*  . Accept N numbers from user and return frequency of even numbers. 
Input : N : 6 
Elements :85 66 3 80 93 88 
Output : 3 
*/
/////////////////////////////////////////////////////////////////////////////////////////////////////

#include<stdio.h>
#include<stdlib.h>

int Add(int*brr,int isize)
{
    int icnt=0;
    int ifer=0;
for(icnt=0;icnt<isize;icnt++)
{
    if(brr[icnt]%2==0)
    {
        ifer++;
    }  
} 
return ifer;
}

int main()
{
    int*arr=NULL;
    int icnt=0;
    int iret=0,len=0;

    printf("Enter number of elements(lenght):\n");
    scanf("%d",&len);

    arr=(int*)malloc(len*sizeof(int));

           if(arr == NULL) 
{ 
    printf("Unable to allocate memory"); 
    return -1; 
} 

printf("Enter numbers:\n");
    for(icnt=0;icnt<len;icnt++)
{
    scanf("%d",&arr[icnt]);
}   

iret=Add(arr,len); 
printf("Frequency of even numbers  is:%d",iret);

free(arr);

    return 0;
}