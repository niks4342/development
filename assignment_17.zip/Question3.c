/*   . Accept N numbers from user check whether that numbers contains 11 in  it or not. 
Input : N : 6 
Elements :85 66 11 80 93 88 
Output : 11 is present 
Input : N : 6 
Elements :85 66 3 80 93 88 
Output : 11 is absent 
*/
///////////////////////////////////////////////////////////////////////////////////////////////////////

#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
bool Check(int *brr,int isize)
{
    int icnt=0;
    
for(icnt=0;icnt<isize;icnt++)
{
    if(brr[icnt]==11)
    {
        return true;
    }
    
} 
}

int main()
{
    int*arr=NULL;
    int icnt=0;
    int len=0;
    bool fret=false;
    
     printf("Enter number of elements(lenght):\n");
    scanf("%d",&len);

    arr=(int*)malloc(len*sizeof(int));

    if(arr == NULL) 
{ 
    printf("Unable to allocate memory"); 
    return -1; 
} 

printf("Enter numbers:\n");
    for(icnt=0;icnt<len;icnt++)
{
    scanf("%d",&arr[icnt]);
}   

fret=Check(arr,len);

if(fret==true)
{
    printf("11 is present\n");
}
else 
{
    printf("11 is absent\n");
}
free(arr);

return 0;
}