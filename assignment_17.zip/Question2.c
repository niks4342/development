/*  Accept N numbers from user and return difference between frequency of  even number and odd numbers. 
Input : N : 7 
Elements :85 66 3 80 93 88 90 
Output : 1 (4 -3)
*/

#include<stdio.h>
#include<stdlib.h>

int Diff(int*brr,int isize)
{
    int icnt=0;
    int efer,ofer=0;
for(icnt=0;icnt<isize;icnt++)
{
    if(brr[icnt]%2==0)
    {
        efer++;
    }  
    else
    {
        ofer++;
    }
} 
return efer-ofer ;
}

int main()
{
    int*arr=NULL;
    int icnt=0;
    int iret=0,len=0;

    printf("Enter number of elements(lenght):\n");
    scanf("%d",&len);

    arr=(int*)malloc(len*sizeof(int));

    if(arr == NULL) 
{ 
    printf("Unable to allocate memory"); 
    return -1; 
} 

printf("Enter numbers:\n");
    for(icnt=0;icnt<len;icnt++)
{
    scanf("%d",&arr[icnt]);
}   

iret=Diff(arr,len);
printf("Difference between even frequency and odd frequency is:%d",iret);

free(arr);

    return 0;
}