/* Q.5   Write a program which accept one number from user and on its first 4  bits. Return modified number. 
Input : 73 
Output : 79 
*/


#include<stdio.h>
#include<stdbool.h>

typedef unsigned int UINT;

int CheckBit(UINT ino)
{
    UINT iret=0;
    UINT imask=0x0000000F;

    iret=ino & imask;

    if(iret==imask)
    {
       imask=0xFFFFFFF0;
       iret=ino & imask;
       return iret;
    }
    else if (iret!=imask)
    {
        imask=0x0000000F;
        iret=ino | imask;
        return iret;
    }
    
   
}

int main()
{
    UINT ivalue=0;
    int iret=0;

    printf("Enter the number:\n");
    scanf("%d",&ivalue);

    iret=CheckBit(ivalue);
    printf("modified number is:%d\n",iret);

    return 0;
}