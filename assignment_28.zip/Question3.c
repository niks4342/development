/* Q.3   Write a program which accept one number from user and toggle 7th bit of  that number. Return modified number. 
Input : 137 
Output : 201
*/


#include<stdio.h>
#include<stdbool.h>

typedef unsigned int UINT;

int CheckBit(UINT ino)
{
    UINT iret=0;
    UINT imask=0x00000040;

    iret=ino & imask;

    if(iret==imask)
    {
       imask=0xFFFFFFBF;
       iret=ino & imask;
       return iret;
    }
    else if (iret!=imask)
    {
        imask=0x00000040;
        iret=ino | imask;
        return iret;
    }
    
   
}

int main()
{
    UINT ivalue=0;
    int iret=0;

    printf("Enter the number:\n");
    scanf("%d",&ivalue);

    iret=CheckBit(ivalue);
    printf("modified number is:%d\n",iret);

    return 0;
}