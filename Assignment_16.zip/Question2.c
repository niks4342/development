/*   Accept N numbers from user and display all such elements which are  divisible by 5. 
Input : N : 6 
Elements :85 66 3 80 93 88 
Output : 85 80 
*/
///////////////////////////////////////////////////////////////////////////////////////////////////////////

#include<stdio.h>
#include<stdlib.h>

void Display(int brr[],int isize)
{
    int icnt=0;
    int isum=0;
for(icnt=0;icnt<isize;icnt++)
{
    if(brr[icnt]%5==0)
    {
        printf("Numbers divisible by 5 is :%d\n",brr[icnt]);
    }  
} 

}

int main()
{
    int*arr=NULL;
    int icnt,len=0;
   

    printf("Enter number of elements(lenght):\n");
    scanf("%d",&len);

    arr=(int*)malloc(len*sizeof(int));

    if(arr == NULL) 
{ 
    printf("Unable to allocate memory"); 
    return -1; 
} 


printf("Enter numbers:\n");
    for(icnt=0;icnt<len;icnt++)
{
    scanf("%d",&arr[icnt]);
}   

Display(arr,len); 
free(arr);

    return 0;
}