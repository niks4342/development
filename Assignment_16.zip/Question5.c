/*   . Accept N numbers from user and display all such elements which are  multiples of 11. 
Input : N : 6 
Elements :85 66 3 55 93 88 
Output : 66 55 88 
*/
///////////////////////////////////////////////////////////////////////////////////////////////////////////


#include<stdio.h>
#include<stdlib.h>

void Diff(int brr[],int isize)
{
    int icnt=0;
   
for(icnt=0;icnt<isize;icnt++)
{
    if(brr[icnt]%11==0)
    {
       printf("Numbers are :%d\n",brr[icnt]);
    }  
}


}

int main()
{
    int*arr=NULL;
    int icnt=0;
    int len=0;

    printf("Enter number of elements(lenght):\n");
    scanf("%d",&len);

    arr=(int*)malloc(len*sizeof(int));

       if(arr == NULL) 
{ 
    printf("Unable to allocate memory"); 
    return -1; 
} 

printf("Enter numbers:\n");
    for(icnt=0;icnt<len;icnt++)
{
    scanf("%d",&arr[icnt]);
}   
Diff(arr,len); 


free(arr);

    return 0;
}