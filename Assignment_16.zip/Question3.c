/*    Accept N numbers from user and display all such elements which are  even and divisible by 5. 
Input : N : 6 
Elements :85 66 3 80 93 88 
Output : 80 
*/
//////////////////////////////////////////////////////////////////////////////////////////////////////

#include<stdio.h>
#include<stdlib.h>

void Diff(int brr[],int isize)
{
    int icnt=0;
   
for(icnt=0;icnt<isize;icnt++)
{
    if(brr[icnt]%2==0 &&(brr[icnt]%5==0))
    {
       printf("Number is: %d\n",brr[icnt]);
    }  
   
} 

}

int main()
{
    int*arr=NULL;
    int icnt=0;
    int len=0;

    printf("Enter number of elements(lenght):\n");
    scanf("%d",&len);

    arr=(int*)malloc(len*sizeof(int));

       if(arr == NULL) 
{ 
    printf("Unable to allocate memory"); 
    return -1; 
} 

printf("Enter numbers:\n");
    for(icnt=0;icnt<len;icnt++)
{
    scanf("%d",&arr[icnt]);
}   
Diff(arr,len); 


free(arr);

    return 0;
}
