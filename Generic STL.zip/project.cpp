#include<iostream>
using namespace std;

template<typename T>

struct node
{
    T data;
    struct node*next;
    struct node* prev;
};

template<typename T>
struct inode
{
    T data;
    struct inode*lchild;
    struct inode*rchild;
};

//////////////////////////////////////////////////////////////////////////////////
//Class Name: BST
// Discription : This class represent the non-linear data structure i.e 
//              Binary Search Tree
//
//////////////////////////////////////////////////////////////////////////////////

template<class T>
class BST
{
private:
    inode<T>* first;  
    int size;
    
public:

   BST();
    void Insert(T no);

    bool Search(T no);

    void Display();

    int Count();
};


///////////////////////////////////////////////////////////////////////////////////
//  Class Name      :       singlyLL
//  Discription     :       This class represent the singly linear linked list
//
///////////////////////////////////////////////////////////////////////////////////

template<class T>
class SinglyLL
{
private:
    node<T>* first;  
    int size;
    
public:

    SinglyLL();

    void InsertFirst(T);

    void InsertLast(T);

    void InsertAtPos(T , int);

    void DeleteFirst();

    void DeleteLast();

    void DeleteAtPos(int);

    void Display();

    int Count();

    void Perfect();

    void Prime();

    int EvenSum();

};

///////////////////////////////////////////////////////////////////////////////////
//  Class Name      :       singlyCL
//  Discription     :       This class represent the singly circular linked list
//
///////////////////////////////////////////////////////////////////////////////////

template<class T>
class singlyCL
{
    private:
    node<T>* frist;      
    node<T>* last;      
    int size;

    public:

    singlyCL();

    void InsertFirst(T);

    void InsertLast(T);

    void InsertAtPos(T , int);

    void DeleteFirst();

    void DeleteLast();

    void DeleteAtPos(int);

    void Display();

    int Count();
    
};

///////////////////////////////////////////////////////////////////////////////////
//  Class Name      :       DoublyLL
//  Discription     :       This class represent the doubly linear linked list
//
///////////////////////////////////////////////////////////////////////////////////


template<class T>
class DoublyLL
{
    private:
    node<T>* first;
    int size;

    public:
    
    DoublyLL();

    void InsertFirst(T);

    void InsertLast(T);

    void InsertAtPos(T , int);

    void DeleteFirst();

    void DeleteLast();

    void DeleteAtPos(int);

    void Display();

    int Count();
  
};


///////////////////////////////////////////////////////////////////////////////////
//  Class Name      :       DoublyCL
//  Discription     :       This class represent the doubly circular linked list
//
///////////////////////////////////////////////////////////////////////////////////

template<class T>
class DoublyCL
{
private:
    node<T>* first;
    node<T>* last;
    int size;
    
public:
  
    DoublyCL();

    void Display();

    int Count();

    void InsertFirst(T no);

    void InsertLast(T no);

    void InsertAtPos(T no , int ipos);

    void DeleteFirst();

    void DeleteLast();

    void DeleteAtPos(int ipos);
};
///////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////
//  Function Name       :      BST
//  parameters          :       NONE
//  Discription         :       This is the constructor of BST class
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////

template<class T>

BST<T>::BST()
{
    first=NULL;
    size=0;
}

///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       Insert
//  parameters          :       int data
//             This function hold the data which is to be added in the non linear linked list
//  Discription         :       This function add the node to in the linked list at 
//                              desired position
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////

template<class T>

void BST<T>::Insert(T no)
{
    inode<T>* newn=new inode<T>;

    newn->data=no;
    newn->lchild=NULL;
    newn->rchild=NULL;

    if(first==NULL)
    {
        first=newn;
    }
    else
    {
        inode<T>* temp=first;

        while(1)
       
        {
           if(temp->data==no)
           {
               cout<<"Duplicate node\n";

               delete newn;
               break;
           }

           else if(temp->data > no)
           {
               if(temp->lchild==NULL)
               {
                   temp->lchild=newn;
                   break;
               }
               temp=temp->lchild;
           }

           else if(temp->data < no)
           {
                if(temp->rchild==NULL)
               {
                   temp->rchild=newn;
                   break;
               }
               temp=temp->rchild;
           }
        }
    }
    size++;
}

///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       Search
//  parameters          :       int data
//             This function hold the data which is to be search from the non linear linkedlist
//  Discription         :       This function search the given data ,whethere that data 
//                              is present or not 
//  Returns             :       bool(if data present return true else return false)
//
///////////////////////////////////////////////////////////////////////////////////


template<class T>
bool BST<T>::Search(T no)
{
    inode<T>* temp=first;
    if(temp==NULL)//if tree if empty
    {
        return false;
    }
    else
    {
        while(temp!=NULL)
        {
            if(temp->data==no)
            {
                return true;
                break;
            }
            else if(no>(temp->data))
            {
                temp=temp->rchild;
            }
            else if(no<(temp->data))
            {
                temp=temp->lchild;
            }

        }
        if(temp==NULL)
        {
            return false;
        }
        else
        {
            return true;
        }
    }
}


//////////////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       Count
//  parameters          :       NONE
//             
//  Discription         :       This function Count the number of nodes from the 
//                              non-linear linkelist
//  Returns             :       Size of linked list(int)
//
/////////////////////////////////////////////////////////////////////////////////////////

template<class T>

int BST<T>::Count()
{
    return size;
}

//////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       singlyLL
//  parameters          :       NONE
//  Discription         :       This is the constructor of singlyLL class
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////

template<class T>
SinglyLL<T>::SinglyLL()
   {
       first = NULL;
       size = 0;
   }

///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       InsertFirst
//  parameters          :       int data
//             This function hold the data which is to be added int the linked list
//  Discription         :       This function add the node to in the linked list at 
//                              first position
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////

template<class T>
void SinglyLL<T>::InsertFirst(T no)
   {
       //Memory allocate to the new node

       node<T>* newn = new node<T>;  
       
       //Initilise the node with its data

       newn->data = no;
       newn->next = NULL;
       
       if(first == NULL)
       {
           first = newn;
       }
       else
       {
           newn->next = first;
           first = newn;
       }

       //As the node gets inserted to the linked list
       //size of linked list increase by one

       size++;
   }

///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       InsertLast
//  parameters          :       int data
//             This function hold the data which is to be added int the linked list
//  Discription         :       This function add the node to in the linked list at 
//                              Last position
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////

template<class T>
void SinglyLL<T>::InsertLast(T no)
   {
       //Memory allocate to the new node

        node<T>* newn = new node<T>; 

       ////Initilise the node with its data

       newn->data = no;
       newn->next = NULL;
       
       if(first == NULL)
       {
           first = newn;
       }
       else
       {
            node<T>* temp = first;
           
           while(temp->next != NULL)
           {
               temp = temp->next;
           }
           temp->next = newn;
       }
        //As the node gets inserted to the linked list
       //size of linked list increase by one

       size++;
   }

//////////////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       Count
//  parameters          :       NONE
//             
//  Discription         :       This function Count the number of nodes from the linkedlist 
//                              Last position
//  Returns             :       Size of linked list
//
/////////////////////////////////////////////////////////////////////////////////////////

template<class T>
int SinglyLL<T>::Count()
   {
       
       return size;
   }

///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       InserAtPos
//  parameters          :       int data and int pos
//             This function hold the data which is to be added int the linked list
//                 and position where to add the node
//
//  Discription         :       This function add the node to in the linked list at 
//                              any position
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////


template<class T>
void SinglyLL<T>::InsertAtPos(T no, int pos)
{
    int size=0;
    
    node<T>* temp=first;
    int i=0;

    size=Count();

//If the position is Invalid
    if((pos<1)||(pos>size+1))
    {
       
        return;
    }

//Want to Insert node at first position
    if(pos==1)
    {
        InsertFirst(no);
    }

//Insert node at last position
    else if(pos==size+1)
    {
        InsertLast(no);
    }

//Insert node at any position other than first and last
    else
    {
        //Memory allocate to the new node

        node<T>* newn=new node<T>;

        //Initilise the node with its data

        newn->data=no;
        newn->next=NULL;
       
        for(i=1;i<pos-1;i++)
        {
            temp=temp->next;
        }
        newn->next=temp->next;
      
        temp->next=newn;

    }
}

//////////////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       Perfect()
//  parameters          :      NONE
//                         
//  Discription         :       This function display  all perfect 
//                              numbers from singly linear linkedlist
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////

template<class T>

void SinglyLL<T>::Perfect()
{
    int icnt=0,isum=0;
    node<T>* temp=first;
    while(temp!=NULL)
    {
       for(icnt=1;icnt<=(temp->data)/2;icnt++)
        {
        
            if((temp->data)%icnt==0)
            {
                isum=isum+icnt; 
                 
                if(isum==temp->data)
                {
                    printf("perfect:%d\n",temp->data);
                }      
            }
           
        }
        
        temp=temp->next;
        isum=0;
        
    }
  
}

//////////////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       Prime()
//  parameters          :      NONE
//                         
//  Discription         :       This function display  all prime
//                              numbers from singly linear linkedlist
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////

template<class T>

void SinglyLL<T>::Prime()
{
    int icnt=0;

    node<T>* temp=first;
    
    while(temp!=NULL)
    {
     
       for(icnt=2;icnt<=(temp->data)/2;icnt++)
        {
        
            if((temp->data)%icnt==0)
            {
              break;     
            }    
            else if((temp->data)%icnt!=0)
            {
                cout<<"prime:"<<temp->data<<"\n";
            }
           
        }    
        temp=temp->next;     
        
    }
  
}
//////////////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       EvenSum()
//  parameters          :      NONE
//                         
//  Discription         :       This function display  the addition of all even
//                              numbers from singly linear linkedlist
//  Returns             :      Addition of even nodes(int)
//
///////////////////////////////////////////////////////////////////////////////////
template<class T>

int SinglyLL<T>::EvenSum()
{
    int isum=0;
    node<T>* temp=first;

    while(temp!=NULL)
    {   
            if((temp->data)%2==0)
            {
                isum=isum+(temp->data);    
            }
        temp=temp->next;   
    }
    return isum;
  
}


///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       DeleteFirst
//  parameters          :       NONe   
//  Discription         :       This function delete the node at first position
//                              in singly liner linked list
//
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////

template<class T>
void SinglyLL<T>::DeleteFirst()
   {
        node<T>* temp = first;
       
       if(first != NULL)
       {
           first = first->next;

           // Delete the memoery allocated to the first node

           delete temp;
           
           //As the node delete size variable gets decresed by one

           size--;
       }
   }

///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       DeleteLast
//  parameters          :       NONE  
//  Discription         :       This function delete the node at Last position
//                              in singly liner linked list
//
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////

   template<class T>
   void SinglyLL<T>::DeleteLast()
   {
       //Tempporery avriable to travell the linke list
        node<T>* temp = first;
       
       //If the linke list is EMPTY
       if(first == NULL)
       {
           return;
       }

       //if the linked list having single node in it
       else if(first->next == NULL)
       {
           delete first;
           first = NULL;
           size--;
       }

       //If linked list having Multiple nodes in it
       else
       {
           while(temp->next->next != NULL)
           {
               temp = temp->next;
           }
           
           //Deallocate the memory of last node from the liked list
           delete temp->next;

           temp->next = NULL;

           //As the node delete size variable gets decresed by one
           size--;
       }
   }

///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       DeleteAtPos
//  parameters          :       int pos
//              This function accepet the position of the node  
//
//  Discription         :       This function delete the node at any position
//                              in singly liner linked list
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////

template<class T>
void SinglyLL<T>::DeleteAtPos(int pos)
   {
    int size=0;
    node<T>* newn=NULL;
    node<T>* temp=first;
    node<T>* targeted=NULL;
   
    int i=0;

    size=Count();

    //If the enterd position is invalid
    if((pos<1)||(pos>size))
    {
        
        return;
    }

    //if enterd position is one then DeleteFirst function get called

    if(pos==1)
    {
        DeleteFirst();
    }

    //if enterd position is equal to the size of linked list then DeleteFirst 
    //function get called

    else if(pos==size)
    {
        DeleteLast();
    }

    //Enterd positon is other then first and last
    else
    {
        for(i=1;i<pos-1;i++)
        {
            temp=temp->next;
        }

        targeted=temp->next;
        temp->next=targeted->next;
        
        delete targeted;

        ////As the node delete size variable gets decresed by one
        size--;

    }
}

///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       Display
//  parameters          :       NONE 
//
//  Discription         :       This function Display the nodes of linked list
//                              
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////

template<class T>
void SinglyLL<T>::Display()
   {
       node<T>* temp = first;
       
       while(temp!= NULL)
       {
           cout<<temp->data<<"\t";
           temp = temp->next;
       }
       cout<<"\n";
   }

/////////////////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       singlyCL
//  parameters          :       NONE
//  Discription         :       This is the constructor of singlyCL class
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////

template<class T>
singlyCL<T>::singlyCL()
    {
        frist=NULL;
        last=NULL;
        size=0;
    }

///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       Display
//  parameters          :       NONE 
//
//  Discription         :       This function Display the nodes of linked list
//                              
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////

template<class T>
void singlyCL<T>::Display()
    {
        node<T>* temp=frist;

        if((frist==NULL)&&(last==NULL))
        {
            return;
        }

        do
        {
           cout<<"|"<<temp->data<<"|->";
           temp=temp->next;
        } while (temp!=last->next);

        cout<<"\n";
        
    }


///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       Count
//  parameters          :       NONE 
//
//  Discription         :       This function return the count of nodes in 
//                              singly circular linked list
//  Returns             :       size of linked list
//
///////////////////////////////////////////////////////////////////////////////////

template<class T>
int singlyCL<T>::Count()
    {
        return size;
    }


///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       InseretFirst
//  parameters          :       int data
//                      This function hold the data which is to be added int the linked list
//  Discription         :       This function Insert the node at first position               
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////

template<class T>
void singlyCL<T>::InsertFirst(T no)
    {
        //Memory allcated to the new node
       node<T>* newn=new node<T>;

        //Initilise the data of node
        newn->data=no;
        newn->next=NULL;

        //If the linked list is EMPTY

        if((frist==NULL)&&(last==NULL))
        {
            frist=newn;
            last=newn;
        }

        //If the linked list contains node in it
        else
        {
            newn->next=frist;
            frist=newn;
        }
        last->next=frist;

        //As the node added size variable gets incresed by one

        size++;
    }

///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       InseretLast
//  parameters          :       int data
//                      This function hold the data which is to be added int the linked list
//  Discription         :       This function Insert the node at last position               
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////


template<class T>
void singlyCL<T>::InsertLast(T no)
    {
        node<T>* newn=new node<T>;

        newn->data=no;
        newn->next=NULL;

        if((frist==NULL)&&(last==NULL))
        {
            frist=newn;
            last=newn;
        }
        else
        {
            last->next=newn;
            last=newn;

        }
        last->next=frist;

        //As the node added size variable gets incresed by one

        size++;
    }

///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       InseretAtPos
//  parameters          :       int data
//                      This function hold the data which is to be added int the linked list
//  Discription         :       This function Insert the node at last position               
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////

template<class T>
void singlyCL<T>::InsertAtPos(T no,int pos)
    {
           int size=0;
    
    node<T>* temp=frist;
    int i=0;

    size=Count();

    //If the entered position is invalid
    if((pos<1)||(pos>size+1))
    {
        
        return;
    }

    //first position
    if(pos==1)
    {
        InsertFirst(no);
    }

    //last position
    else if(pos==size+1)
    {
        InsertLast(no);
    }

    //Inbetween position
    else
    {
        node<T>* newn=new node<T>;

        newn->data=no;
        newn->next=NULL;
       
        for(i=1;i<pos-1;i++)
        {
            temp=temp->next;
        }
        newn->next=temp->next;
      
        temp->next=newn;

        //As the node added size variable gets incresed by one

        size++;
    }
}

///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       DeleteFirst
//  parameters          :       NONE
//                      
//  Discription         :       This function delete the first node of linke list              
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////

template<class T>
void singlyCL<T>::DeleteFirst()
    {
        //linked list is EMPTY
        if((frist==NULL)&&(last==NULL))
        {
            return;
        }

        //If the linked list conatin only one node in it
        else if(frist==last)
        
        {
            delete(frist);
            frist=NULL;
            last=NULL;
        }

        //linked list contains multiple nodes in it
        else
        {
            frist=frist->next;
           delete last->next;

           last->next=frist;

        }

        //As the node added size variable gets incresed by one

        size --;
    }

///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       DeleteLast
//  parameters          :       NONE
//                      
//  Discription         :       This function delete the Last node of linke list              
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////


template<class T>
void singlyCL<T>::DeleteLast()
    {
        node<T>* temp=frist;


        //If the linked list is EMPTY
        if((frist==NULL)&&(last==NULL))
        {
            return;
        }

        //If the linked list contains single node
        else if(frist==last)
        {
            delete(frist);
            frist=NULL;
            last=NULL;
        }

        //If the linked list contains multiple node
        else
        {

            while(temp->next!=last)
            {
                temp=temp->next;
            }
                delete(last);
                last=temp;

                last->next=frist;

        }

        //As the node deleted size variable gets decresed by one 

        size --;
    }

///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       DeleteAtPos
//  parameters          :       int pos
//                      This function accepet the position
//  Discription         :       This function delete the node at given position of 
//                                linke list              
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////


template<class T>
void singlyCL<T>::DeleteAtPos(int pos)
    {
    int size=0;
    node<T>* newn=NULL;
    node<T>* temp=frist;
    node<T>* targeted=NULL;
   
    int i=0;

    size=Count();

    //If the enterd position is invalid
    if((pos<1)||(pos>size))
    {
        
        return;
    }

    //first position
    if(pos==1)
    {
        DeleteFirst();
    }

    //last position
    else if(pos==size)
    {
        DeleteLast();
    }

    //Inbetween position
    else
    {
        for(i=1;i<pos-1;i++)
        {
            temp=temp->next;
        }
        targeted=temp->next;
        temp->next=targeted->next;
        
        //Deallocate the memory of node at given position

        delete targeted;

        //As the node deleted size variable gets decresed by one

        size--;
    }

}

/////////////////////////////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       DoublyLL
//  parameters          :       NONE
//  Discription         :       This is the constructor of DoublyLL class
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////

template<class T>
DoublyLL<T>::DoublyLL()
    {
        first=NULL;
       
        size=0;
    }


///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       InsertFirst
//  parameters          :       int data
//                       This function accept the data of node to be inserted
//  Discription         :       This function Insert the node at first position 
//                              of Doubly linear linked list
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////


template<class T>
void DoublyLL<T>::InsertFirst(T no)
    {
        node<T>* newn=new node<T>;

        newn->data=no;
        newn->next=NULL;
        newn->prev=NULL;

        if(first==NULL)
        {
            first=newn;
        }

        else
        {
            newn->next=first;
            first->prev=newn;
            first=newn;
        }

        //As the node added size variable gets incresed by one

        size++;
    }

///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       InsertLast
//  parameters          :       int data
//                       This function accept the data of node to be inserted
//  Discription         :       This function Insert the node at Last position 
//                              of Doubly linear linked list
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////

template<class T>
void DoublyLL<T>::InsertLast(T no)
    {
        //memory allocation to the new node

        node<T>* newn=new node<T>;
        node<T>* temp=first;

        newn->data=no;
        newn->next=NULL;
        newn->prev=NULL;

        if(first==NULL)
        {
            first=newn;
        }


        else
        {
            while(temp->next!=NULL)
            {
                temp=temp->next;
            }
            
            temp->next=newn;
            newn->prev=temp;
        }

        //As the node added size variable gets incresed by one

        size++;
    }

///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :      count
//  parameters          :       NONE              
//  Discription         :       This function count the number of nodes from 
//                             the doubly linear linked list
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////


template<class T>
int DoublyLL<T>::Count()
    {
        return size;
    }


///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       InsertAtPos
//  parameters          :       int data and int pos
//                       This function accept the data of node to be inserted
//                          and position whrere to be insrted
//  Discription         :       This function Insert the node at any given position 
//                              of Doubly linear linked list
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////


template<class T>
void DoublyLL<T>::InsertAtPos(T no,int pos)
    {
        int size=0;
    
    node<T>* temp=first;
    int i=0;

    size=Count();

//Invalid position
    if((pos<1)||(pos>size+1))
    {
        
        return;
    }

    //first position

    if(pos==1)
    {
        InsertFirst(no);
    }

    //last position

    else if(pos==size+1)
    {
        InsertLast(no);
    }

    //Inbetween position

    else
    {
        node<T>* newn=new node<T>;

        newn->data=no;
        newn->next=NULL;
        newn->prev=NULL;
       
        for(i=1;i<pos-1;i++)
        {
            temp=temp->next;
        }

        newn->next=temp->next;
        newn->prev=temp;
        temp->next=newn;
        temp->next->prev=newn;
       
    }

    //As the node added size variable gets incresed by one

     size++;
}

///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       DeleteFirst
//  parameters          :       NONE
//                                      
//  Discription         :       This function delete the node at first position 
//                              of Doubly linear linked list
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////

template<class T>
void DoublyLL<T>::DeleteFirst()
    {
        node<T>* temp=first;
        if(first!=NULL)
        {
            first=first->next;

            delete temp;

            if(first!=NULL)
            {
                first->prev=NULL;
            }

        //As the node deleted size variable gets decresed by one

            size--;
        }
    }

///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       DeleteLast
//  parameters          :       NONE
//                                      
//  Discription         :       This function delete the node at last position 
//                              of Doubly linear linked list
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////


template<class T>
void DoublyLL<T>::DeleteLast()
    {
       node<T>* temp=first;

       //If linked list is EMPTY

       if(first==NULL)
       {
           return;
       }

        //if linked list contains only one node

        else if(first->next==NULL)
       {
           delete first;
           first=NULL;
           size--;
       }

       //If the linked list contain more then one node

       else
       {
           while(temp->next!=NULL)
           {
               temp=temp->next;
           }
            temp->prev->next=NULL;
        
        //Deallocate the memory for the node at last position

           delete temp;

        //As the node deleted size variable gets decresed by one

           size--;
       }
    }

///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       DeleteAtPos
//  parameters          :       int pos
//                       this function accepet the position         
//  Discription         :       This function delete the node at any given position 
//                              of Doubly linear linked list
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////


template<class T>    
void DoublyLL<T>::DeleteAtPos(int pos)
    {
    int size=0;
    node<T>* newn=NULL;
    node<T>* prev=NULL;
    node<T>* temp=first;
    node<T>* targeted=NULL;
   
    int i=0;

    size=Count();

//if the position is invalid

    if((pos<1)||(pos>size))
    {
       
        return;
    }

//Position is given as first

    if(pos==1)
    {
        DeleteFirst();
    }

//Position is given as last

    else if(pos==size)
    {
        DeleteLast();
    }

//delete the ode at any given position accept first and last
    else
    {
        for(i=1;i<pos-1;i++)
        {
            temp=temp->next;
        }

        targeted=temp->next;
        temp->next=targeted->next;
        targeted->next->prev=temp;
        
        //deallocate the memory

        delete targeted;

        //As the node deleted size variable gets decresed by one

        size--;
    }

}


///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       DeleteAtPos
//  parameters          :       int pos
//                       this function accepet the position         
//  Discription         :       This function delete the node at any given position 
//                              of Doubly linear linked list
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////

template<class T>
void DoublyLL<T>::Display()
    {
        node<T>* temp=first;

        while(temp!=NULL)
        {
            cout<<"|"<<temp->data<<"|->";
            temp=temp->next;
        }
        cout<<"\n";
    }

//////////////////////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       DoublyCL
//  parameters          :       NONE
//  Discription         :       This is the constructor of DoublyCL class
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////

template<class T>

DoublyCL<T>::DoublyCL()
    {
        first = NULL;
        last = NULL;
        size = 0;
    }
    
///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       InsertFirst
//  parameters          :       int data
//                       this function data to be inserted in the node        
//  Discription         :       This function insert the node at first position 
//                              of Doubly circular linked list
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////


template<class T>
void DoublyCL<T>::InsertFirst(T no)
{
    //Memory alloction to the new node

    node<T>* newn = new node<T>;
    
    //initilise the node with data

    newn->data = no;
    newn->next = NULL;
    newn->prev = NULL;
    
    //if linked list id EMPTY

    if((first == NULL) && (last == NULL))
    {
        first = newn;
        last = newn;
    }

    else
    {
        newn->next = first;
        first -> prev = newn;
        first = newn;
    }
    
    last->next = first;
    first->prev = last;

    //As the node inserted size variable gets incresed by one

    size++;
}

///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       InsertLast
//  parameters          :       int data
//                       this function data to be inserted in the node        
//  Discription         :       This function insert the node at Last position 
//                              of Doubly circular linked list
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////


template<class T>
void DoublyCL<T>::InsertLast(T no)
{
    //memory allocation to the new node

    node<T>* newn = new node<T>;
    
    //initilise the node with data
    newn->data = no;
    newn->next = NULL;
    newn->prev = NULL;
    
    if((first == NULL) && (last == NULL))
    {
        first = newn;
        last = newn;
    }

    else
    {
        last -> next = newn;
        newn->prev = last;
        last = newn;
    }
    
    last->next = first;
    first->prev = last;

    //As the node inserted size variable gets incresed by one

    size++;
}

///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       Count
//  parameters          :       NONE
//                              
//  Discription         :       This function count number of nodes
//                              of Doubly circular linked list
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////

template<class T>

int DoublyCL<T>::Count()
{
    return size;
}

///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       InsertAtPos
//  parameters          :       int data and int pos
//                       this function data to be inserted in the node and position       
//  Discription         :       This function insert the node at any given position 
//                              of Doubly circular linked list
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////

template<class T>

void DoublyCL<T>::InsertAtPos(T no, int ipos)
{
    //If position is invalid

    if((ipos < 1) || (ipos > size+1))
    {
        return;
    }
    
    if(ipos == 1)
    {
        InsertFirst(no);
    }

    else if(ipos == size +1)
    {
        InsertLast(no);
    }

    else
    {
        node<T>* newn= new node<T>;
        
        newn->data = no;
        newn->next = NULL;
        newn->prev = NULL;
        
        node<T>* temp = first;
        
        for(int i = 1; i < ipos -1; i++)
        {
            temp = temp -> next;
        }
        
        newn->next = temp->next;
        newn->next->prev = newn;
        temp->next = newn;
        newn->prev = temp;

        //As the node inserted size variable gets incresed by one

        size ++;
    }
}

///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       DeleteFirst
//  parameters          :      NONE
//                             
//  Discription         :       This function delete the node at first position 
//                              of Doubly circular linked list
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////

template<class T>
void DoublyCL<T>::DeleteFirst()
{
    //If the linked list is EMPTY
    if((first == NULL) && (last == NULL))
    {
        return;
    }

    //Linked list conatins only one node
    else if(first == last)
    {
        delete first;
        first  = NULL;
        last = NULL;
    }

    else
    {
        first = first -> next;

        delete last->next;

        first->prev = last;
        last->next = first;
    }

    //As the node deleted size variable gets decresed by one

    size--;
}

///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       DeleteLast
//  parameters          :      NONE
//                             
//  Discription         :       This function delete the node at last position 
//                              of Doubly circular linked list
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////

template<class T>

void DoublyCL<T>::DeleteLast()
{
    //If the linked list is EMPTY

    if((first == NULL) && (last == NULL))
    {
        return;
    }

    //Linked list conatins only one node

    else if(first == last)
    {
        delete first;
        first  = NULL;
        last = NULL;
    }

    else
    {
        last = last -> prev;
        delete last->next;
        first->prev = last;
        last->next = first;
    }

    //As the node deleted size variable gets decresed by one

    size--;
}

///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       DeleteAtPos
//  parameters          :      int pos
//                       This function accept the position   
//  Discription         :       This function delete the node at any given position 
//                              of Doubly circular linked list
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////

template<class T>

void DoublyCL<T>::DeleteAtPos(int ipos)
{

    if((ipos < 1) || (ipos > size))
    {
        return;
    }

    if(ipos ==1)
    {
        DeleteFirst();
    }


    else if(ipos == size)
    {
        DeleteLast();
    }

    else
    {
        node<T>* temp = first;
        
        for(int i = 1; i < ipos -1 ; i ++)
        {
            temp = temp -> next;
        }
       
        temp -> next = temp->next->next;
        delete temp->next->prev;
        temp->next->prev = temp;
        

        //As the node deleted size variable gets decresed by one

        size--;
    }
}

///////////////////////////////////////////////////////////////////////////////////
//  Function Name       :       Display
//  parameters          :      NONE
//                         
//  Discription         :       This function display the all nodes 
//                              of Doubly circular linked list
//  Returns             :       NONE
//
///////////////////////////////////////////////////////////////////////////////////

template<class T>
void DoublyCL<T>::Display()
{
    node<T>* temp = first;
    
    for(int i = 1; i <= size; i++)
    {
        cout<<"|"<<temp->data<<"|-> ";
        temp = temp->next;
    }
    cout<<"\n";
}


////////////////////////////////////////////////////////////////////////////////////////////////
int main()
{
   SinglyLL<int> lobj;
    
    int iret = 0,pos=0;

    lobj.InsertFirst(51);
    lobj.InsertFirst(21);
    lobj.InsertFirst(11);
    lobj.InsertFirst(6);
    lobj.InsertFirst(12);
    lobj.InsertAtPos(211,3);
    lobj.InsertLast(101);
    lobj.InsertLast(111);
    
    lobj.Display();
    
    lobj.DeleteAtPos(3);
    lobj.Display();
    
    iret = lobj.Count();
    cout<<"Number of elemensts are : "<<iret<<"\n";

    lobj.Prime();
    lobj.Perfect();

    iret=lobj.EvenSum();
    cout<<"Sumation of even numbers/nodes from given linkelist is:"<<iret<<"\n";
    
    ////////////////////////////////////////////////////////////////////////////////////////////////

    singlyCL<int> cobj;
    
    cobj.InsertFirst(51);
    cobj.InsertFirst(21);
    cobj.InsertFirst(11);
    cobj.InsertAtPos(211,3);
    cobj.InsertLast(101);
    cobj.InsertLast(111);
    
    cobj.Display();


    cobj.DeleteAtPos(3);
    cobj.Display();
    
    iret = cobj.Count();
    cout<<"Number of elemensts are : "<<iret<<"\n";

//////////////////////////////////////////////////////////////////////////////////////////////////
    BST<int> bobj;
    int no=0;
    
    bool bret=false;

    bobj.Insert(51);
    bobj.Insert(21);
    bobj.Insert(101);
    
    cout<<"Enter number:\n";
    cin>>no;

    bret=bobj.Search(no);
    if(bret==true)
    {
        cout<<"data is there\n";
    }
    else
    {
        cout<<"Data is not there\n";
    }
 
    iret=bobj.Count();
    cout<<"Count of nodes is:"<<iret<<"\n";
    
    return 0;
}