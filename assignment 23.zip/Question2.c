/*  Write a program which accept string from user and convert it into  upper case. 
Input : “Marvellous Multi OS” 
Output : MARVELLOUS MULTI OS 
*/



#include<stdio.h>
void Capital(char *str)
{
    
    int i=0;
    while(str[i]!='\0')
    {
        if(str[i]>='a' && str[i]<='z')
        {
            str[i]-=32;   
        }
        i++;
    } 
     printf("Uppercase string is:%s\n",str);
}

int main()
{
    char arr[30];
    int iret=0;

    printf("Enter the string:\n");
    scanf("%[^'\n']s",arr);

    Capital(arr);
  

    return 0;
}