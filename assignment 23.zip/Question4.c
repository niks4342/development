/*  Write a program which accept string from user and display only  digits from that string. 
Input : “marve89llous121” 
Output : 89121 
*/


#include<stdio.h>

void Display(char*str)
{
    printf("Numbers from string are:\n");
    while(*str!='\0')
    {
        if((*str>='0')&&(*str<='9'))
        {
           
            printf("%c\n",*str);
        }
        str++;
    }
}

int main()
{
    char arr[50];

    printf("Enter string:\n");
    scanf("%[^'\n']s",arr);

    Display(arr);

    return 0;
}