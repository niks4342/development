/*  Write a program which accept string from user and convert it into  lower case. 
Input : “Marvellous Multi OS” 
Output : marvellous multi os
*/

#include<stdio.h>
void Small(char *str)
{
    
   
    int i=0;
    
    
    while(str[i]!='\0')
    {
        if(str[i]>='A' && str[i]<='Z')
        {
            str[i]+=32;   
        }
        i++;
    } 
     printf("Uppercase string is:%s\n",str);
}

int main()
{
    char arr[30];
    int iret=0;

    printf("Enter the string:\n");
    scanf("%[^'\n']s",arr);

    Small(arr);
  

    return 0;
}